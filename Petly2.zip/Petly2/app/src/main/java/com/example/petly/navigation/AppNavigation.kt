package com.example.petly.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.petly.data.db.AppDatabase
import com.example.petly.ui.theme.screens.auth.LoginScreen
import com.example.petly.ui.theme.screens.auth.RegisterScreen
import com.example.petly.ui.theme.screens.home.HomeScreen

@Composable
fun AppNavigation(database: AppDatabase) {
    val navController = rememberNavController()

    NavHost(navController, startDestination = "login") {
        composable("login") {
            LoginScreen(
                onLoginSuccess = { navController.navigate("home") },
                onNavigateToRegister = { navController.navigate("register") }
            )
        }
        composable("register") {
            RegisterScreen(
                onRegisterSuccess = { navController.navigate("home") },
                onNavigateToLogin = { navController.popBackStack() }
            )
        }
    }}
       /* composable("home") {
            HomeScreen(
                onLogout = { navController.navigate("login") }
            )
        }
    }
}*/