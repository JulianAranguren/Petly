package com.example.petly.data.db.daos


import androidx.room.*
import com.example.petly.model.Pet
import kotlinx.coroutines.flow.Flow

@Dao
interface PetDao {
    // Insertar nueva mascota
    @Insert
    suspend fun insertPet(pet: Pet)

    // Actualizar mascota existente
    @Update
    suspend fun updatePet(pet: Pet)

    // Eliminar mascota
    @Delete
    suspend fun deletePet(pet: Pet)

    // Obtener todas las mascotas de un dueño (Flow para observación en tiempo real)
    @Query("SELECT * FROM pet WHERE ownerEmail = :ownerEmail ORDER BY name ASC")
    fun getPetsByOwner(ownerEmail: String): Flow<List<Pet>>

    // Obtener mascota por ID
    @Query("SELECT * FROM pet WHERE id = :petId LIMIT 1")
    suspend fun getPetById(petId: Long): Pet?

    // Buscar mascotas por nombre
    @Query("SELECT * FROM pet WHERE name LIKE :query AND ownerEmail = :ownerEmail")
    fun searchPets(query: String, ownerEmail: String): Flow<List<Pet>>
}