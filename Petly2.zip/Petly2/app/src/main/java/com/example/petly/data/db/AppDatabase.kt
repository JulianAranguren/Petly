package com.example.petly.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.petly.data.db.daos.PetDao
import com.example.petly.data.db.daos.ReminderDao
import com.example.petly.data.db.daos.UserDao
import com.example.petly.model.Pet
import com.example.petly.model.Reminder
import com.example.petly.model.User

@Database(
    entities = [User::class, Pet::class, Reminder::class],
    version = 2
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun petDao(): PetDao
    abstract fun reminderDao(): ReminderDao

    companion object {
        private const val DATABASE_NAME = "petly.db"

        // Migración de v1 a v2
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("""
                    CREATE TABLE reminders (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        petId INTEGER NOT NULL,
                        type TEXT NOT NULL,
                        date TEXT NOT NULL,
                        notes TEXT,
                        isCompleted INTEGER NOT NULL DEFAULT 0,
                        FOREIGN KEY(petId) REFERENCES pets(id) ON DELETE CASCADE
                    )
                """)
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DATABASE_NAME
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}