package com.example.petly

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.petly.data.db.AppDatabase
import com.example.petly.navigation.AppNavigation
import com.example.petly.ui.theme.PetlyTheme

class MainActivity : ComponentActivity() {
    // Inicialización correcta con Singleton
    private val database by lazy { AppDatabase.getInstance(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PetlyTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavigation(database = database)
                }
            }
        }
    }
}