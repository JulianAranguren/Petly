package com.example.petly.data.db.daos

import androidx.room.*
import com.example.petly.model.Reminder
import kotlinx.coroutines.flow.Flow
import java.util.*

@Dao
interface ReminderDao {
    // Insertar nuevo recordatorio
    @Insert
    suspend fun insertReminder(reminder: Reminder)

    // Actualizar recordatorio existente
    @Update
    suspend fun updateReminder(reminder: Reminder)

    // Eliminar recordatorio
    @Delete
    suspend fun deleteReminder(reminder: Reminder)

    // Obtener todos los recordatorios de una mascota
    @Query("SELECT * FROM reminders WHERE petId = :petId ORDER BY date ASC")
    fun getRemindersForPet(petId: Long): Flow<List<Reminder>>

    // Obtener recordatorios próximos (para notificaciones)
    @Query("SELECT * FROM reminders WHERE date BETWEEN :startDate AND :endDate AND petId = :petId")
    suspend fun getUpcomingReminders(
        petId: Long,
        startDate: String,
        endDate: String
    ): List<Reminder>

    // Obtener recordatorio por ID
    @Query("SELECT * FROM reminders WHERE id = :reminderId LIMIT 1")
    suspend fun getReminderById(reminderId: Long): Reminder?
}